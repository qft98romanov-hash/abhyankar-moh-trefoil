Appendix 2 — Ivan Dorofeev — 28 October 2026
Research branch: UNDER VERIFICATION.

Upload this ZIP as a new project at https://www.overleaf.com/.
Main document: main.tex
Compiler: XeLaTeX (two passes for references and the table of contents).
All included sections, references and text fonts are bundled.
No shell escape, external images, or network downloads are required.

The separate full research archive includes the exact computation scripts,
fresh normal/optimized logs, previous repository material and an update patch.
The final compiled PDF is delivered separately.
